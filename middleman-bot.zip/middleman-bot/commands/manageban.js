const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('manageban')
    .setDescription('Ban a user from the server with logging')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(opt => opt.setName('user').setDescription('The user to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the ban').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    let rolesOwned = 'Members';
    if (member) {
      const roles = member.roles.cache
        .filter(r => r.id !== interaction.guild.id)
        .map(r => r.name)
        .join(', ');
      if (roles) rolesOwned = roles;
    }

    try {
      await interaction.guild.members.ban(target.id, { reason });
    } catch (err) {
      return interaction.reply({ content: `❌ Failed to ban: ${err.message}`, ephemeral: true });
    }

    const now = new Date();
    const timestamp = now.toLocaleDateString('en-US', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    }) + ' ' + now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    const banEmbed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle('User Banned 🚫')
      .addFields(
        { name: 'Actioned By', value: `${interaction.user.username} (${interaction.user.id})`, inline: false },
        { name: 'Target User', value: `${target.username} (${target.id})`, inline: false },
        { name: 'Roles Owned', value: rolesOwned, inline: false },
        { name: 'Reason', value: reason, inline: false },
        { name: 'Time', value: timestamp, inline: false },
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const banLogsChannel = interaction.guild.channels.cache.get(config.BAN_LOGS);
    if (banLogsChannel) await banLogsChannel.send({ embeds: [banEmbed] });

    await interaction.reply({ embeds: [banEmbed] });
  },
};
