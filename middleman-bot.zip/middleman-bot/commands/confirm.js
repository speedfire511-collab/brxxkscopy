const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('confirm')
    .setDescription('Start a trade confirmation between two traders')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addUserOption(opt => opt.setName('trader1').setDescription('Trader 1').setRequired(true))
    .addUserOption(opt => opt.setName('trader2').setDescription('Trader 2').setRequired(true))
    .addStringOption(opt => opt.setName('info').setDescription('Trade information').setRequired(true)),

  async execute(interaction) {
    const trader1 = interaction.options.getUser('trader1');
    const trader2 = interaction.options.getUser('trader2');
    const info = interaction.options.getString('info');

    const embed = new EmbedBuilder()
      .setColor(0xf5a623)
      .setTitle('✅ Trade Confirmation')
      .setDescription('Both traders must confirm to continue this trade.')
      .addFields(
        { name: '📊 Trade Information', value: info, inline: false },
        { name: '👤 Trader 1', value: `<@${trader1.id}>`, inline: true },
        { name: '👤 Trader 2', value: `<@${trader2.id}>`, inline: true },
        {
          name: '⏳ Awaiting Confirmation',
          value: `🔴 <@${trader1.id}>\n🔴 <@${trader2.id}>`,
          inline: false,
        }
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`confirm_t1_${trader1.id}_${trader2.id}`)
        .setLabel('✅ Confirm Trade (Trader 1)')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`confirm_t2_${trader1.id}_${trader2.id}`)
        .setLabel('✅ Confirm Trade (Trader 2)')
        .setStyle(ButtonStyle.Success)
    );

    await interaction.reply({
      content: `<@${trader1.id}> <@${trader2.id}>`,
      embeds: [embed],
      components: [row],
    });
  },
};
