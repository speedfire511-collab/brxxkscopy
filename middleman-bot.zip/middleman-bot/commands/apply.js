const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setupapply')
    .setDescription('Post the staff application panel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('📋 Staff Applications')
      .setDescription(
        'Want to become part of the team? Click a button below to open a private application ticket.\n\n' +
        '**🛡️ Middleman** — Safely handle trades between server members.\n\n' +
        '**⚔️ Moderator** — Manage, moderate, and keep the server safe.\n\n' +
        '**⭐ OG Access** — Apply for exclusive OG member status.\n\n' +
        '> A private ticket will be created where staff can review your application.'
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('apply_middleman')
        .setLabel('🛡️ Middleman')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('apply_moderator')
        .setLabel('⚔️ Moderator')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('apply_og')
        .setLabel('⭐ OG Access')
        .setStyle(ButtonStyle.Success)
    );

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
