const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setupmiddleman')
    .setDescription('Post the middleman request panel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xf5a623)
      .setTitle('🤝 Middleman Services')
      .addFields(
        {
          name: 'Middleman Service',
          value: 'To request a middleman from this server, click the blue **"Request Middleman"** button on this message.',
        },
        {
          name: 'How does middleman work?',
          value:
            '• Example: Trade is Frost Dragon for Corrupt.\n' +
            '• Trader #1 gives Frost Dragon to middleman.\n' +
            '• Trader #2 gives Corrupt to middleman.\n' +
            '• Middleman gives the respective pets to each trader.',
        },
        {
          name: '⚠️ DISCLAIMER!',
          value: 'You must both agree on the deal before using a middleman. Troll tickets will have consequences.',
        }
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('request_middleman')
        .setLabel('📋 Request Middleman')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
