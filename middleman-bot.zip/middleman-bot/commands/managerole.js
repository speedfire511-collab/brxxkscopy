const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('managerole')
    .setDescription('Add or remove a role from a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addStringOption(opt =>
      opt.setName('action').setDescription('Add or remove').setRequired(true)
        .addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' })
    )
    .addUserOption(opt => opt.setName('user').setDescription('Target user').setRequired(true))
    .addRoleOption(opt => opt.setName('role').setDescription('Role to add/remove').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    const action = interaction.options.getString('action');
    const target = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) return interaction.reply({ content: '❌ User not found.', ephemeral: true });

    try {
      if (action === 'add') await member.roles.add(role.id, reason);
      else await member.roles.remove(role.id, reason);
    } catch (err) {
      return interaction.reply({ content: `❌ Failed: ${err.message}`, ephemeral: true });
    }

    const color = action === 'add' ? 0x2ecc71 : 0xe74c3c;
    const actionLabel = action === 'add' ? '➕ Role Added' : '➖ Role Removed';

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(actionLabel)
      .addFields(
        { name: 'Actioned By', value: `${interaction.user.username} (${interaction.user.id})`, inline: false },
        { name: 'Target User', value: `${target.username} (${target.id})`, inline: false },
        { name: 'Role', value: `${role.name} (${role.id})`, inline: false },
        { name: 'Reason', value: reason, inline: false },
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const promoChannel = interaction.guild.channels.cache.get(config.PROMOTION_CHANNEL);
    if (promoChannel) await promoChannel.send({ embeds: [embed] });

    await interaction.reply({ embeds: [embed] });
  },
};
