const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rules')
    .setDescription('Display the server rules'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x2b2d31)
      .setTitle('📜 Server Rules')
      .setDescription(
        '**1. No Scamming — Zero Tolerance**\n' +
        'Any form of scam, fraud, fake deal, or offering fake middleman servers will result in an instant ban.\n' +
        "We're a trusted server built for real, safe trades, not for taking advantage of others.\n\n" +

        '**2. Be Respectful & Honest**\n' +
        'Always treat other members with respect and fairness.\n' +
        'Lying, misleading others, or wasting time will not be tolerated.\n\n' +

        '**3. Keep Communication Clear**\n' +
        'Use proper language when trading or streaming.\n' +
        'No gore, nudity, inappropriate posts (instant ban).\n' +
        'No spamming, trolling, or off-topic messages during trade talks or streams.\n\n' +

        '**4. Proof of Trade (Optional but Recommended)**\n' +
        'You can record or screenshot your trades to help keep the community transparent and trustworthy.\n' +
        'Admins may ask for proof in case of disputes.\n\n' +

        '**5. Report Scammers Immediately**\n' +
        'If someone attempts to scam or act suspiciously, report them to staff right away.\n' +
        "We'll investigate and take action fast.\n\n" +

        '**6. No Impersonation**\n' +
        'Do not impersonate staff, middlemen, or other members. This will result in an immediate ban.\n\n' +

        '**7. Follow Discord TOS**\n' +
        "All members must follow Discord's Terms of Service at all times. Violations will not be tolerated.\n\n" +

        '**8. Max 1 Active Middleman Ticket**\n' +
        'You may only have one open middleman ticket at a time. Creating duplicate tickets will result in them being closed immediately.'
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    await interaction.reply({ embeds: [embed] });
  },
};
