const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('middleman')
    .setDescription('Explains what a middleman is'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('ℹ️ What is a Middleman?')
      .setDescription(
        '• A middleman is a **trusted go-between** who holds payment until the seller delivers goods or services.\n\n' +
        '• The funds are released once the buyer confirms everything is as agreed.\n\n' +
        '• This process helps **prevent scams, build trust, and resolve disputes**.\n\n' +
        '• Common in **valuable games, real-life money trades, in-game currency, and collectibles**.\n\n' +
        '• Only works safely if the middleman is **reputable and verified**.'
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    await interaction.reply({ embeds: [embed] });
  },
};
