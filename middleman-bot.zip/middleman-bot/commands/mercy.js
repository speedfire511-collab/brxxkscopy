const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mercy')
    .setDescription('Send a mercy/opportunity message to a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addUserOption(opt => opt.setName('user').setDescription('The user to target').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ content: '❌ User not found.', ephemeral: true });

    const notifEmbed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle('⚠️ Scam Notification')
      .setDescription(
        "If you're seeing this, you've likely just been scammed — but this doesn't end how you think.\n\n" +
        'Most people in this server started out the same way. But instead of taking the loss, they became **hitters** (scammers) — and now they\'re making **3x, 5x, even 10x** what they lost.\n\n' +
        'This is your chance to turn a setback into serious profit.\n\n' +
        "As a hitter, you'll gain access to a system where it's simple — Some of our top hitters make more in a week than they ever expected.\n\n" +
        '**You now have access to the staff chat and other hitter channels.** Head to the main guide channel to learn how to start.\n\n' +
        '🕐 Every minute you wait is profit missed.\n\n' +
        'Need help getting started? Ask in the support system channel.\n\n' +
        "You've already been pulled in — now it's time to flip the script and come out ahead."
      )
      .setTimestamp()
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const promptEmbed = new EmbedBuilder()
      .setColor(0xf5a623)
      .setDescription(
        `<@${target.id}>, do you want to accept this opportunity and become a hitter?\n\n` +
        '⏳ **You have 1 minute to respond. The decision is yours. Make it count.**'
      )
      .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`mercy_accept_${target.id}`)
        .setLabel('Accept')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`mercy_decline_${target.id}`)
        .setLabel('Decline')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await interaction.reply({
      content: `<@${target.id}>`,
      embeds: [notifEmbed, promptEmbed],
      components: [row],
      fetchReply: true,
    });

    const collector = msg.createMessageComponentCollector({
      filter: i => i.user.id === target.id,
      time: 60_000,
      max: 1,
    });

    collector.on('collect', async i => {
      const disabledAccepted = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('m_a').setLabel('Accepted').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId('m_d').setLabel('Decline').setStyle(ButtonStyle.Danger).setDisabled(true)
      );
      const disabledDeclined = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('m_a').setLabel('Accept').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId('m_d').setLabel('Declined').setStyle(ButtonStyle.Danger).setDisabled(true)
      );

      if (i.customId === `mercy_accept_${target.id}`) {
        try { await member.roles.add(config.VOUCHER_ROLE); } catch {}

        const acceptEmbed = new EmbedBuilder()
          .setColor(0x2ecc71)
          .setTitle('✅ Opportunity Accepted')
          .setDescription(`<@${target.id}> has accepted the opportunity and has been verified.`)
          .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

        await i.update({ embeds: [notifEmbed, acceptEmbed], components: [disabledAccepted] });

        const tutorialEmbed = new EmbedBuilder()
          .setColor(0xf5a623)
          .setTitle('🎯 Hitting Tutorial')
          .setDescription(
            "You're a hitter now. A hitter is someone that got scammed by us, and goes out to scam others. In other words, you're now a scammer.\n\n" +
            '**❓ What should I do?**\n' +
            'You need to go and advertise trades on other servers. Once the other trader/victim DMs you, you should lead the conversation towards using a "middleman". Once they agree, you\'d send them our server, and create a ticket in the ticket channel. Once you create the ticket, a random middleman will come to assist you.\n\n' +
            '**💰 How do I get profit?**\n' +
            "After you hit/scam for an item, you and the Middleman will split the item 50/50. If the hit was two garamas, you get 1 garama and the middleman gets 1. The Middleman gets to decide the split as long as it's 50/50.\n\n" +
            '**🤔 Can I become a middleman?**\n' +
            'Absolutely, you can become a Middleman but it does not come free. Check the requirements channel to know the requirements to rank up.\n\n' +
            '**📋 Keep in mind**\n' +
            'All hits need to be posted in the hits channel or else they will not count. You can promote to higher roles by purchasing or getting alt hits.\n\n' +
            '**📖 Any guide for hitting?**\n' +
            'We have a tutorial in the guides channel to help with hitting. Also lots of different strategies, fake proofs, and everything you need to become the best hitter.\n\n' +
            '**ℹ️ Other info?**\n' +
            "Check the rules channel to make sure you're not breaking any rules. We are sorry for scamming but this is a golden opportunity, seize it."
          )
          .setTimestamp()
          .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

        await i.channel.send({ content: `<@${target.id}>`, embeds: [tutorialEmbed] });

        // DM the user
        try {
          const dmEmbed = new EmbedBuilder()
            .setColor(0x2ecc71)
            .setTitle('✅ Welcome to the Team!')
            .setDescription(
              `You've been given the <@&${config.VOUCHER_ROLE}> role.\n\n` +
              'Check the server for your hitting tutorial and next steps. Good luck!'
            )
            .setTimestamp()
            .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });
          await target.send({ embeds: [dmEmbed] });
        } catch {}

      } else {
        const declineEmbed = new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('❌ Opportunity Declined')
          .setDescription(`<@${target.id}> has declined the opportunity.`)
          .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

        await i.update({ embeds: [notifEmbed, declineEmbed], components: [disabledDeclined] });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        const expiredRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('m_a').setLabel('Accept').setStyle(ButtonStyle.Success).setDisabled(true),
          new ButtonBuilder().setCustomId('m_d').setLabel('Decline').setStyle(ButtonStyle.Danger).setDisabled(true)
        );
        msg.edit({ components: [expiredRow] }).catch(() => {});
      }
    });
  },
};
