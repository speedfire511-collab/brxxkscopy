# 🤝 Middleman Bot

A full-featured Discord middleman/trading bot with ticket system, applications, banning, and role management.

---

## 📋 Commands

| Command | Description | Who Can Use |
|---|---|---|
| `/rules` | Shows server rules (8 rules including max 1 ticket) | Everyone |
| `/setupmiddleman` | Posts the middleman request panel with button | Staff |
| `/middleman` | Explains what a middleman is | Everyone |
| `/confirm` | Starts trade confirmation between 2 traders | Middlemen |
| `/mercy @user` | Sends the scam opportunity message to a user | Staff |
| `/apply` | Opens application menu (Middleman / Mod / OG Access) | Everyone |
| `/manageban @user reason` | Bans a user + logs to ban-logs | Staff (BanMembers perm) |
| `/managerole add/remove @user @role` | Adds or removes a role + logs | Staff (ManageRoles perm) |

---

## ⚙️ Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Create your `.env` file
```bash
cp .env.example .env
```
Then fill in:
```
BOT_TOKEN=your_bot_token_here
GUILD_ID=your_server_id_here
```

### 3. Verify Channel/Role IDs in `config.js`
All IDs are pre-filled but double-check them:

```js
MIDDLEMAN_ROLE: '1491162667698622604'   // [M] Middleman role
VOUCHER_ROLE:   '1491162667698622603'   // Voucher role (given on mercy accept)
MIDDLEMAN_CATEGORY: '1491162669519212659'
MM_CHANNEL:     '1491162669519212661'   // Where /setupmiddleman panel is posted
TICKET_LOGS:    '1491162670639087735'   // Ticket close logs
MOD_CATEGORY:   '1491058230007304242'
BAN_LOGS:       '1491058334122377267'   // /manageban logs here
PROMOTION_CHANNEL: '1491058366209069126' // /managerole logs + middlemen do trades here
```

### 4. Bot Permissions Required
In Discord Developer Portal, enable:
- **Privileged Intents**: Server Members Intent, Message Content Intent

Your bot needs these permissions in the server:
- Manage Channels
- Manage Roles
- Ban Members
- View Channels / Send Messages / Embed Links
- Read Message History

### 5. Start the bot
```bash
node index.js
```

---

## 🎫 How Ticket System Works

1. Staff runs `/setupmiddleman` → panel appears with **Request Middleman** button
2. User clicks button → private ticket channel created in middleman category
3. Middleman role is pinged in the ticket
4. A middleman clicks **Claim** → confirmed with green embed
5. Staff uses `/confirm @trader1 @trader2 info` inside the ticket for trade confirmation
6. Both traders click their confirm buttons → live status updates (🔴 → 🟢)
7. When both confirm → embed turns green "Trade Confirmed!"
8. Staff clicks **Close** → ticket is logged to ticket-logs and deleted

---

## 📋 Application System

1. User runs `/apply` → buttons for Middleman / Moderator / OG Access
2. Clicking a button opens a **modal form** (5 questions)
3. Submission creates a private ticket with their answers
4. Staff can Accept / Deny / Close from inside the ticket

---

## ⚠️ /mercy Flow

1. Staff runs `/mercy @user`
2. Bot sends scam notification embed + opportunity prompt
3. Target user has **1 minute** to Accept or Decline
4. If accepted:
   - User gets the **Voucher role**
   - Hitting tutorial embed is sent in channel
   - User receives a DM with welcome message
5. If declined or timeout → buttons disabled

---

## 🔨 /manageban

- Bans the user
- Logs to `#ban-logs` with: who actioned, target user ID, roles they had, reason, and timestamp
- Matches the embed style shown in your screenshot

## 👑 /managerole

- Add or remove any role from any user
- Logs the action to the promotion channel
