const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../config');

// Track trade confirmation state per message
const confirmState = new Map();

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {

    // =========================================================
    // SLASH COMMANDS
    // =========================================================
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction, client);
      } catch (err) {
        console.error(err);
        const reply = { content: '❌ An error occurred.', ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(reply);
        else await interaction.reply(reply);
      }
      return;
    }

    // =========================================================
    // BUTTONS
    // =========================================================
    if (!interaction.isButton()) return;

    const { customId, guild, user } = interaction;

    // ---------------------------------------------------------
    // REQUEST MIDDLEMAN — creates MM ticket channel
    // ---------------------------------------------------------
    if (customId === 'request_middleman') {
      // Check for existing open ticket (max 1)
      const existing = guild.channels.cache.find(
        c =>
          c.name === `mm-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 20)}` &&
          c.type === ChannelType.GuildText
      );
      if (existing) {
        return interaction.reply({
          content: `❌ You already have an open middleman ticket: <#${existing.id}>`,
          ephemeral: true,
        });
      }

      await interaction.deferReply({ ephemeral: true });

      const ticketChannel = await guild.channels.create({
        name: `mm-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 20)}`,
        type: ChannelType.GuildText,
        parent: config.MIDDLEMAN_CATEGORY,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
          },
          {
            id: config.MIDDLEMAN_ROLE,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
          },
        ],
      });

      const ticketEmbed = new EmbedBuilder()
        .setColor(0xf5a623)
        .setTitle('🎫 Middleman Ticket')
        .setDescription(
          `<@${user.id}>, Thank you for using our middleman services.\n\n` +
          `Please wait for a middleman to assist you.\n\n` +
          `If you have any questions, please let a staff member know.`
        )
        .setTimestamp()
        .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

      const controlRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`mm_claim_${user.id}_${ticketChannel.id}`)
          .setLabel('🟢 Claim')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`mm_close_${ticketChannel.id}`)
          .setLabel('🔒 Close')
          .setStyle(ButtonStyle.Danger)
      );

      await ticketChannel.send({
        content: `<@${user.id}> <@&${config.MIDDLEMAN_ROLE}>`,
        embeds: [ticketEmbed],
        components: [controlRow],
      });

      await interaction.editReply({ content: `✅ Your ticket has been created: <#${ticketChannel.id}>` });
      return;
    }

    // ---------------------------------------------------------
    // CLAIM MM TICKET
    // ---------------------------------------------------------
    if (customId.startsWith('mm_claim_')) {
      const parts = customId.split('_');
      const ticketChannelId = parts[3];

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member || !member.roles.cache.has(config.MIDDLEMAN_ROLE)) {
        return interaction.reply({ content: '❌ Only middlemen can claim tickets.', ephemeral: true });
      }

      const updatedRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('mm_claimed_done')
          .setLabel('🟢 Claimed')
          .setStyle(ButtonStyle.Success)
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId(`mm_close_${ticketChannelId}`)
          .setLabel('🔒 Close')
          .setStyle(ButtonStyle.Danger)
      );

      await interaction.update({ components: [updatedRow] });

      const claimedEmbed = new EmbedBuilder()
        .setColor(0x2ecc71)
        .setTitle('✅ Ticket Claimed')
        .setDescription(`<@${user.id}> will be your Middleman for today.`)
        .setTimestamp()
        .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

      await interaction.channel.send({ embeds: [claimedEmbed] });
      return;
    }

    // ---------------------------------------------------------
    // CLOSE TICKET (MM tickets and application tickets)
    // ---------------------------------------------------------
    if (customId.startsWith('mm_close_')) {
      const ticketChannelId = customId.split('_')[2];
      const ticketChannel = guild.channels.cache.get(ticketChannelId) || interaction.channel;

      const logChannel = guild.channels.cache.get(config.TICKET_LOGS);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('🔒 Ticket Closed')
          .addFields(
            { name: 'Channel', value: ticketChannel.name, inline: true },
            { name: 'Closed By', value: `${user.username} (${user.id})`, inline: true },
          )
          .setTimestamp()
          .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

        await logChannel.send({ embeds: [logEmbed] });
      }

      await interaction.reply({ content: '🔒 Closing ticket in 3 seconds...' });
      setTimeout(() => ticketChannel.delete().catch(() => {}), 3000);
      return;
    }

    // ---------------------------------------------------------
    // TRADE CONFIRM BUTTONS
    // ---------------------------------------------------------
    if (customId.startsWith('confirm_t1_') || customId.startsWith('confirm_t2_')) {
      const parts = customId.split('_');
      const isT1 = parts[1] === 't1';
      const trader1Id = parts[2];
      const trader2Id = parts[3];
      const msgId = interaction.message.id;

      if (!confirmState.has(msgId)) {
        confirmState.set(msgId, { t1: false, t2: false, trader1Id, trader2Id });
      }
      const state = confirmState.get(msgId);

      if (isT1 && user.id !== trader1Id)
        return interaction.reply({ content: '❌ Only Trader 1 can click this button.', ephemeral: true });
      if (!isT1 && user.id !== trader2Id)
        return interaction.reply({ content: '❌ Only Trader 2 can click this button.', ephemeral: true });

      if (isT1) state.t1 = true;
      else state.t2 = true;

      const t1Status = state.t1 ? '🟢' : '🔴';
      const t2Status = state.t2 ? '🟢' : '🔴';
      const bothConfirmed = state.t1 && state.t2;

      const oldEmbed = interaction.message.embeds[0];
      const tradeInfo = oldEmbed.fields.find(f => f.name.includes('Trade Information'))?.value || '';

      const updatedEmbed = new EmbedBuilder()
        .setColor(bothConfirmed ? 0x2ecc71 : 0xf5a623)
        .setTitle(bothConfirmed ? '✅ Trade Confirmed!' : '✅ Trade Confirmation')
        .setDescription(
          bothConfirmed
            ? '**Both traders have confirmed! Trade is good to go.**'
            : 'Both traders must confirm to continue this trade.'
        )
        .addFields(
          { name: '📊 Trade Information', value: tradeInfo, inline: false },
          { name: '👤 Trader 1', value: `<@${trader1Id}>`, inline: true },
          { name: '👤 Trader 2', value: `<@${trader2Id}>`, inline: true },
          {
            name: bothConfirmed ? '✅ Both Confirmed' : '⏳ Awaiting Confirmation',
            value: `${t1Status} <@${trader1Id}>\n${t2Status} <@${trader2Id}>`,
            inline: false,
          }
        )
        .setTimestamp()
        .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

      if (bothConfirmed) {
        const doneRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('c1').setLabel('✅ Confirmed (Trader 1)').setStyle(ButtonStyle.Success).setDisabled(true),
          new ButtonBuilder().setCustomId('c2').setLabel('✅ Confirmed (Trader 2)').setStyle(ButtonStyle.Success).setDisabled(true)
        );
        await interaction.update({ embeds: [updatedEmbed], components: [doneRow] });
        confirmState.delete(msgId);
      } else {
        const updatedRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`confirm_t1_${trader1Id}_${trader2Id}`)
            .setLabel(state.t1 ? '✅ Confirmed (Trader 1)' : '✅ Confirm Trade (Trader 1)')
            .setStyle(state.t1 ? ButtonStyle.Secondary : ButtonStyle.Success)
            .setDisabled(state.t1),
          new ButtonBuilder()
            .setCustomId(`confirm_t2_${trader1Id}_${trader2Id}`)
            .setLabel(state.t2 ? '✅ Confirmed (Trader 2)' : '✅ Confirm Trade (Trader 2)')
            .setStyle(state.t2 ? ButtonStyle.Secondary : ButtonStyle.Success)
            .setDisabled(state.t2)
        );
        await interaction.update({ embeds: [updatedEmbed], components: [updatedRow] });
      }
      return;
    }

    // ---------------------------------------------------------
    // APPLICATION BUTTONS — creates private application ticket
    // ---------------------------------------------------------
    if (['apply_middleman', 'apply_moderator', 'apply_og'].includes(customId)) {
      const typeMap = {
        apply_middleman: 'Middleman',
        apply_moderator: 'Moderator',
        apply_og: 'OG Access',
      };
      const appType = typeMap[customId];
      const safeName = user.username.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 16);

      // Check if they already have an open application ticket
      const existing = guild.channels.cache.find(
        c => c.name === `app-${safeName}` && c.type === ChannelType.GuildText
      );
      if (existing) {
        return interaction.reply({
          content: `❌ You already have an open application ticket: <#${existing.id}>`,
          ephemeral: true,
        });
      }

      await interaction.deferReply({ ephemeral: true });

      const ticketChannel = await guild.channels.create({
        name: `app-${safeName}`,
        type: ChannelType.GuildText,
        parent: config.MIDDLEMAN_CATEGORY,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
          },
          {
            id: config.MIDDLEMAN_ROLE,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
          },
        ],
      });

      const appEmbed = new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle(`📋 ${appType} Application`)
        .setDescription(
          `<@${user.id}> has opened a **${appType}** application ticket.\n\n` +
          `Please answer the following questions in this channel:\n\n` +
          `**1.** How old are you?\n` +
          `**2.** What is your timezone?\n` +
          `**3.** Do you have any prior experience?\n` +
          `**4.** Why do you want to be **${appType}**?\n` +
          `**5.** Anything else you want to add?`
        )
        .setTimestamp()
        .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

      const controlRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`app_accept_${user.id}`)
          .setLabel('✅ Accept')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`app_deny_${user.id}`)
          .setLabel('❌ Deny')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`mm_close_${ticketChannel.id}`)
          .setLabel('🔒 Close')
          .setStyle(ButtonStyle.Secondary)
      );

      await ticketChannel.send({
        content: `<@${user.id}> <@&${config.MIDDLEMAN_ROLE}>`,
        embeds: [appEmbed],
        components: [controlRow],
      });

      await interaction.editReply({
        content: `✅ Your **${appType}** application ticket has been created: <#${ticketChannel.id}>`,
      });
      return;
    }

    // ---------------------------------------------------------
    // APPLICATION ACCEPT
    // ---------------------------------------------------------
    if (customId.startsWith('app_accept_')) {
      const applicantId = customId.split('_')[2];

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member || !member.roles.cache.has(config.MIDDLEMAN_ROLE)) {
        return interaction.reply({ content: '❌ Only staff can accept applications.', ephemeral: true });
      }

      const acceptEmbed = new EmbedBuilder()
        .setColor(0x2ecc71)
        .setTitle('✅ Application Accepted')
        .setDescription(
          `<@${applicantId}>, your application has been **accepted**!\n\n` +
          `A staff member will be in touch with next steps. Welcome to the team!`
        )
        .setTimestamp()
        .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('app_a').setLabel('✅ Accepted').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId('app_d').setLabel('❌ Deny').setStyle(ButtonStyle.Danger).setDisabled(true),
        new ButtonBuilder().setCustomId('app_c').setLabel('🔒 Close').setStyle(ButtonStyle.Secondary).setDisabled(true)
      );

      await interaction.update({ components: [disabledRow] });
      await interaction.channel.send({ embeds: [acceptEmbed] });

      // DM the applicant
      try {
        const dmEmbed = new EmbedBuilder()
          .setColor(0x2ecc71)
          .setTitle('✅ Application Accepted!')
          .setDescription(
            `Your application in **${guild.name}** has been accepted!\n\n` +
            `A staff member will reach out with further instructions.`
          )
          .setTimestamp()
          .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

        const applicant = await guild.members.fetch(applicantId).catch(() => null);
        if (applicant) await applicant.send({ embeds: [dmEmbed] }).catch(() => {});
      } catch {}
      return;
    }

    // ---------------------------------------------------------
    // APPLICATION DENY
    // ---------------------------------------------------------
    if (customId.startsWith('app_deny_')) {
      const applicantId = customId.split('_')[2];

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member || !member.roles.cache.has(config.MIDDLEMAN_ROLE)) {
        return interaction.reply({ content: '❌ Only staff can deny applications.', ephemeral: true });
      }

      const denyEmbed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('❌ Application Denied')
        .setDescription(
          `<@${applicantId}>, your application has been **denied**.\n\n` +
          `You may re-apply in the future. Thank you for applying!`
        )
        .setTimestamp()
        .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('app_a').setLabel('✅ Accept').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId('app_d').setLabel('❌ Denied').setStyle(ButtonStyle.Danger).setDisabled(true),
        new ButtonBuilder().setCustomId('app_c').setLabel('🔒 Close').setStyle(ButtonStyle.Secondary).setDisabled(true)
      );

      await interaction.update({ components: [disabledRow] });
      await interaction.channel.send({ embeds: [denyEmbed] });

      // DM the applicant
      try {
        const dmEmbed = new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('❌ Application Denied')
          .setDescription(
            `Your application in **${guild.name}** has been denied.\n\n` +
            `You're welcome to apply again in the future!`
          )
          .setTimestamp()
          .setFooter({ text: config.FOOTER_TEXT, iconURL: config.FOOTER_ICON });

        const applicant = await guild.members.fetch(applicantId).catch(() => null);
        if (applicant) await applicant.send({ embeds: [dmEmbed] }).catch(() => {});
      } catch {}
      return;
    }

  },
};
